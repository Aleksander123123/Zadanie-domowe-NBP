
public class Rate {
	public String currency;
	public String code;
	public double mid;
}
