import java.util.List;

public class ExchangeRatesTable {
	public String table;
	public List<Rate> rates;
}
