import java.io.IOException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

import com.google.gson.Gson;
import com.google.gson.JsonArray;

public class Main {
	
	public static void main(String[] args) throws IOException {
		// adres api do pobrania akutalnych kursów
		URL url = new URL("http://api.nbp.pl/api/exchangerates/tables/A");
		// nawiązanie połączenia z api
		URLConnection connection = url.openConnection();
		Scanner scanner = new Scanner(connection.getInputStream());
		// wczytanie danych do Stringa
		String jsonText = scanner.nextLine();
		
		// skonwertowanie Stringa do Tablicy
		Gson gson = new Gson();
		JsonArray jsonArray = gson.fromJson(jsonText, JsonArray.class);

		// zwracane dane są tablicą jednoelementową, więc pobieram ten jeden elementy (indeks = 0)
		System.out.println(jsonArray.get(0));
		// parsuję jsonObject do obiektu javowego
		ExchangeRatesTable pojo = gson.fromJson(jsonArray.get(0), ExchangeRatesTable.class);
		
		// przechodze przez wszystkie dane
		for(Rate rate : pojo.rates) {
			// dla USD, EUR, GBP, CHF wyświetlam kurs oraz przelicznik ile warte jest 100 zł w tych walutach
			if(rate.code.equals("USD") || rate.code.equals("EUR") || rate.code.equals("GBP") || rate.code.equals("CHF")) {
				System.out.println("Kurs "+rate.code+" : "+rate.mid);	
				System.out.println("100zł <=> "+(100/rate.mid)+" "+rate.code);	
			}	
		}
		
	}
}
